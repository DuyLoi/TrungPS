/**
 * Created by HuyNT2.
 * Updated by TUANNM5 (05/08/2016)
 * User:
 * Date: 21/04/2015
 * Time: 5:35 PM
 */

var CONST_DEBUG_MODE = true;
var CONST_CONFIG_FILEPATH = "C:\\_eb_ecounter\\";
var CONST_CONFIG_NAME = "config.json";
var CONST_LOG_FILEPATH = "C:\\_eb_ecounter\\log\\";
var CONST_LOG_FILENAME = "TPBankAddon";
var CONST_SIDEBAR_TITLE = "TPBank Auto-FCC Version : 1.5.6";
var CONST_IS_GET_CONFIG = false;
var IP_SERVER = "";
//test
// var CONST_TRACKING_TAB_URL = "http://10.1.14.231:7003/FCJNeoWeb/SMMDIFRM.jsp";
//live
var CONST_TRACKING_TAB_URL = "http://fcc12.tpb.vn/FCJNeoWeb/LoginServlet";
var CFG_OBJ = {
	"EC_Url_Server_Public" : "http://ecounter.tpb.vn/ECounterWebserviceVer5.asmx",
	// "EC_Url_Server_Public": "http://10.1.14.20:8081/ECounterWebserviceVer5.asmx",
	"FCC_Url": "http://fcc12.tpb.vn/FCJNeoWeb/LoginServlet",
	"FCC_Keyword": "FCJNeoWeb",
	"FCC_User": "CAONT",
	"FCC_Password": "Pasword@3",
	"Sidebar_Title": "TPBank Auto-FCC Version : 1.5.6",
	"Sidebar_Width": "280px",
	"EC_Url": "http://10.1.14.240:8070/service1.asmx",
	"EC_Timer_GetComingCustomer": "3000",
	"EC_Username_Key": "___COUNTER_USERNAME___",
	"EC_Customer_CIF_Key": "___CUSTOMER_CIF_KEY___",
	"EC_Cust_TrackingID_Key": "___CUST_TRACKING_ID_KEY___",
	"EC_Cust_BookingID_Key": "___CUST_BOOKING_ID_KEY___",
	"EC_Iframe_Fcc_Id_Key": "___ECOUNTER_IFRAME_FCC_ID___",
	"EC_Iframe_Fcc_Url_Key": "___ECOUNTER_IFRAME_FCC_URL_KEY___",
	"EC_Iframe_Over_Fcc_Script": "var elIframe=document.getElementById('___ECOUNTER_IFRAME_FCC_ID___');if(elIframe) {elIframe.parentNode.removeChild(elIframe);}var frmCustImg = document.createElement('iframe');frmCustImg.setAttribute('id', '___ECOUNTER_IFRAME_FCC_ID___');frmCustImg.setAttribute('src', '___ECOUNTER_IFRAME_FCC_URL_KEY___');frmCustImg.style.border = 'none';frmCustImg.style.overflow = 'hidden';frmCustImg.style.width = '572px';frmCustImg.style.height = '286px';frmCustImg.style.position = 'absolute';frmCustImg.style.bottom = '0px';frmCustImg.style.right = '0px';frmCustImg.style.zIndex = 5;document.body.appendChild(frmCustImg);",
	"EC_Clean_Iframe_Fcc_Script": "var elIframe=document.getElementById('___ECOUNTER_IFRAME_FCC_ID___');if(elIframe) {elIframe.parentNode.removeChild(elIframe);}",
	"FCC_Print_VMS_nodeID": "BLK_CUST_DETAILS__BTN_ADVICE#BLK_TRANSACTION_DETAILS__BTN_ADVICE#BLK_CUST_ACCOUNT__BTN_ADVICE#BLK_TD_REDEMPTION__BTN_ADVICE",
	"FCC_Func_Print_Directly": "DEDRTTLR#",
	"FCC_Func_Print_XREF_Node": "BLK_MAIN__XREF#",
	"FCC_Func_Print_Directly_Url": "http://vms.tpb.vn/Modules/advice_print/___FCC_EC_FUNC_KEY___.aspx?xref=___FCC_EC_TRANS_XREF___&TxnType=CMND"
};
var CONST_DATE_YYYYMMDD_CFG = 2;

var CONST_TIMER_GET_PAGE_OBJ = 500; /*đơn vị: ms*/

var self = require("sdk/self");
var Utils = require("./lib/Utils");

/*
	Button action
*/

var btnTPBankAddon = require("sdk/ui/button/action").ActionButton({
	id: "tpbank-addon-fcc",
	label: "TPBank Addon",
	icon: {
		"16": "./icon-16.png",
		"32": "./icon-32.png",
		"64": "./icon-64.png"
	},
	onClick: btnAddonAction
});

var tabFCC;
var { setTimeout } = require("sdk/timers");
var { getTabForId, getTabContentWindow } = require("sdk/tabs/utils");


function btnAddonAction() {

	getConfig();
	if (CFG_OBJ.Sidebar_Title && CFG_OBJ.Sidebar_Title.length > 1) {
		CONST_SIDEBAR_TITLE = CFG_OBJ.Sidebar_Title;
	}
	/*
		Show sidebar
	*/
	sidebarTPBank.show();
	var window = require('sdk/window/utils').getMostRecentBrowserWindow();
	if (CFG_OBJ.Sidebar_Width) {
		window.document.getElementById('sidebar').style.width = CFG_OBJ.Sidebar_Width;
	}
	else {
		window.document.getElementById('sidebar').style.width = "285px";
	}
	var tabs = require("sdk/tabs");

	var FCCStatus = false;
	for (let tab of tabs) {
		if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
			FCCStatus = true;
			tabFCC = tab;
		}
	}
	if (!FCCStatus) {
		tabs.open(CONST_TRACKING_TAB_URL);
	}
	tabs.on('ready', function (tab) {
		if (tab.url == CONST_TRACKING_TAB_URL) {
			tabFCC = tab;
			Common.logInfo("FCC loaded ready!");
			//var window = getTabContentWindow (getTabForId(tab.id));
			var wd = getTabContentWindow(getTabForId(tab.id));
			var docContent = wd.document;
			setTimeout(function (e) {
				Common.logInfo("HuyNT2: " + docContent.getElementById('USERID').value);
			}, CFG_OBJ.EC_Timer_GetComingCustomer);

			tab.attach({
				contentScript: "document.getElementById('USERID').value = '" + CFG_OBJ.FCC_User + "';	document.getElementById('user_pwd').value = '" + CFG_OBJ.FCC_Password + "';"
			});
		}
	});
}

/*
	Sidebar
*/

var Request = require("sdk/request").Request;
var pjson = require('./package.json');
var g_version = "TPBank Auto-FCC Version :" + pjson.version;

var sidebarTPBank = require("sdk/ui/sidebar").Sidebar({
	id: 'tpbank-sidebar',
	/*title: 'TPBank sidebar',
	title: CONST_SIDEBAR_TITLE,*/
	title: g_version,
	url: "./sidebar.html",
	onReady: function (worker) {
		/* Đẩy config ra sidebar */

		logInfoToFile("caont day config ra", "1");
		Common.logInfo("FCC User: " + CFG_OBJ.FCC_User);
		//caont request service get config on server

		worker.port.emit("tpbankAddonGetConfig", CFG_OBJ);

		setTimeout(function () {
			//getConfig();	
			FileUlts.saveFile(CONST_CONFIG_FILEPATH, CONST_CONFIG_NAME, Common.stringFromJSONObj(CFG_OBJ));
			logInfoToFile("confif url affter get from server :  " + CFG_OBJ.EC_Url + "  teller name : " + CFG_OBJ.FCC_User, "1");
			worker.port.emit("tpbankAddonFireEvent", CFG_OBJ);

		}, 6000);

		//worker.port.emit("tpbankAddonFireEvent", CFG_OBJ);
	},
	onAttach: function (worker) {
		/* Bắt sự kiện từ sidebar truyền vào */
		worker.port.on("tpbankSidebarFireEvent", function (msg) {

			// Common.logInfo("Browser url: " + tabFCC.url);
			msg.script = Common.removeAccentff(msg.script);

			if (msg.scriptfile && msg.scriptfile.length > 1) {
				logInfoToFile("add-on script got the message tpbankSidebarFireEvent: " + Common.stringFromJSONObj(msg) + "\n FILE SCRIPT CONTENT: \n" + self.data.load(msg.scriptfile) + "\n", msg.logfile);
			}
			else {
				logInfoToFile("add-on script got the message tpbankSidebarFireEvent: " + Common.stringFromJSONObj(msg), msg.logfile);
			}

			var tabs = require("sdk/tabs");
			for (let tab of tabs) {
				if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
					is_open_fcc = true;
					logInfoToFile("add-on run script: " + Common.stringFromJSONObj(msg), msg.logfile);

					//worker.port.emit("tpbankAddonFireEvent", msg);
					if (msg.scriptfile && msg.scriptfile.length > 1) {
						tab.attach({
							contentScriptFile: self.data.url(msg.scriptfile)
						});
					}
					else {
						tab.attach({
							contentScript: msg.script
						});
					}
				}
			}
		});

		/* Bắt sự kiện từ sidebar truyền vào */
		worker.port.on("tpbankSidebarRequestEvent", function (msg) {

			Common.logInfo("Addon receive request message: " + Common.stringFromJSONObj(msg));
			
			if (msg.funcAction == "GetAutoScript") {
				var tabs = require("sdk/tabs");
				var is_open_fcc = false;
				for (let tab of tabs) {
					if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
						is_open_fcc = true;
					}
				}
				if (!is_open_fcc) {
					msg.funcAction = 'exRunAutoscript';
					// worker.port.emit("tpbankAddonResponseEvent", msg);
				}
			}

			//open edit eform
			if (msg.funcAction == "GetlinkEditEForm") {
				var linkEdit = msg.reqContent;
				var tabsEform = require("sdk/tabs");
				tabsEform.open(linkEdit);
				worker.port.emit("tpbankAddonResponseEvent", msg);

			}/*else if(msg.funcAction == "requestGetAutoScriptEform"){
				var FCCStatus = false;
				var tabs = require("sdk/tabs");
				for (let tab of tabs) {
					if(tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
						FCCStatus = true;
						
					}
								}
				if (FCCStatus) {
					
				}
				
				
			}	*/
			else {
				if (msg.funcAction == "SendReviewTransContent" || msg.funcAction == "LocalXREFFromFCC") {
					var divTarget;
					var iframeTarget;
					var searchStatus = false;
					var docContent;
					var tabs = require("sdk/tabs");

					var FCCStatus = false;
					for (let tab of tabs) {
						if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
							var wd = getTabContentWindow(getTabForId(tab.id));
							docContent = wd.document;
						}
					}
					var fccFuncID = docContent.getElementById('fastpath').value;

					var divLauncher = docContent.getElementById('IFlauncher');
					var arrDivIframes = divLauncher.getElementsByTagName('div');

					for (let tmpDivIframe of arrDivIframes) {
						var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
						if (arrIframes && arrIframes.length > 0) {
							console.log('GET ELEMENT: IFRAME');
							var tmpIframe = arrIframes[0];
							var tmpIframeScr = tmpIframe.getAttribute('src');
							if ((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=' + fccFuncID) != -1)) {
								console.log("GOT IFrame src: " + tmpIframeScr);
								divTarget = tmpDivIframe;
								iframeTarget = tmpIframe;
								searchStatus = true;
								break;
							}
						}
					}
					if (searchStatus && msg.funcAction == "SendReviewTransContent") {
						var docIframe = iframeTarget.contentDocument;
						var tmpArrInfo = msg.reqContent.match("<reviewContent>(.*)</reviewContent");
						var tmpArrInfoID = tmpArrInfo[1].split('#');
						var tmpArrFCCInfo = new Array();
						for (let tmpNodeID of tmpArrInfoID) {
							if (docIframe.getElementById(tmpNodeID)) {
								if (docIframe.getElementById(tmpNodeID).type == 'checkbox') {
									if (docIframe.getElementById(tmpNodeID).checked) {
										tmpArrFCCInfo.push('1');
										Common.logInfo("HuyNT2123 checkbox: 1");
									}
									else {
										tmpArrFCCInfo.push('0');
										Common.logInfo("HuyNT2123 checkbox: 0");
									}
								}
								else {
									tmpArrFCCInfo.push(docIframe.getElementById(tmpNodeID).value);
									Common.logInfo("HuyNT2123: " + docIframe.getElementById(tmpNodeID).value);
								}
							}
							else {
								tmpArrFCCInfo.push("");
							}
						}

						msg.reqContent = msg.reqContent.replace(tmpArrInfo[1], tmpArrFCCInfo.join("#"));
						Common.logInfo("New FCC Info: " + msg.reqContent);
					}
					if (searchStatus && msg.funcAction == "LocalXREFFromFCC") {
						var docIframe = iframeTarget.contentDocument;
					}
				}


				var strRequest = "<?xml version='1.0' encoding='utf-8'?>";
				strRequest = strRequest + "<soap:Envelope " +
					"xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' " +
					"xmlns:xsd='http://www.w3.org/2001/XMLSchema' " +
					"xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>";
				strRequest = strRequest + " <soap:Body>";

				strRequest = strRequest + "<" + msg.funcAction + " xmlns=\"http://tempuri.org/\">";
				strRequest = strRequest + msg.reqContent;
				strRequest = strRequest + "</" + msg.funcAction + ">";

				strRequest = strRequest + "</soap:Body>";
				strRequest = strRequest + "</soap:Envelope>";

				var reqECService;
	

				if (msg.funcAction == "requestGetInforFromServer") {

					reqECService = Request({
						url: CFG_OBJ.EC_Url_Server_Public,
						contentType: "text/xml; charset=utf-8",
						headers: {
							"SOAPAction": "http://tempuri.org/" + msg.funcAction
						},
						content: strRequest,
						onComplete: function (response) {
							if (response && response.text && msg.funcAction == "requestGetInforFromServer") {
						

								if (response && response.text) {
									var respStrArr = response.text.match("&lt;IP_SERVER&gt;(.*)&lt;/IP_SERVER&gt");
									var respStrArrPort = response.text.match("&lt;PORT&gt;(.*)&lt;/PORT&gt");
									var portServer;

									if (respStrArrPort && respStrArrPort.length > 0) {
										portServer = Common.removeAccentff(respStrArrPort[1]);
									}

									if (respStrArr && respStrArr.length > 0) {
										msg.respResult = Common.removeAccentff(respStrArr[1]);
									}

									logInfoToFile("Response result of service requestGetInforFromServer " + msg.funcAction + " with REQUEST: " + msg.reqContent + " and RESPONSE : " + msg.respResult, "1");

									IP_SERVER = msg.respResult;
							
									//caont hardcode sau bo di
									CFG_OBJ.EC_Url	= "http://"+ IP_SERVER +":"+portServer+"/service1.asmx";
									// CFG_OBJ.EC_Url = "http://localhost:24256/Service1.asmx";
									logInfoToFile(" url : " + CFG_OBJ.EC_Url, "1");

									worker.port.emit("tpbankAddonResponseEvent", msg);

								}

							}

						}
					});


				}
				else {
					reqECService = Request({
						url: CFG_OBJ.EC_Url,
						contentType: "text/xml; charset=utf-8",
						headers: {
							"SOAPAction": "http://tempuri.org/" + msg.funcAction
						},
						content: strRequest,
						onComplete: function (response) {

						

							if (response && response.text && msg.funcAction == "requestGetTellerName") {
								var respStrArr = response.text.match("&lt;STRING&gt;(.*)&lt;/STRING&gt");
								if (respStrArr && respStrArr.length > 0) {
									msg.respResult = Common.removeAccentff(respStrArr[1]);
								}
								CFG_OBJ.FCC_User = msg.respResult;

								logInfoToFile("confif url :  " + CFG_OBJ.EC_Url + "  teller name : " + CFG_OBJ.FCC_User, "1");

								worker.port.emit("tpbankAddonResponseEvent", msg);

							}
							else {
								//code cu
								if (response && response.text) {

									var respStrArr = response.text.match("<" + msg.funcAction + "Result>(.*)</" + msg.funcAction + "Result>");


									if (respStrArr && respStrArr.length > 0) {
										msg.respResult = Common.removeAccentff(respStrArr[1]);
									}

									//	logInfoToFile("Response result of service " + msg.funcAction + " with REQUEST: " + msg.reqContent + " and RESPONSE : " + msg.respResult, "1"); // + " FULL_RESPONSE: " + response.text

									worker.port.emit("tpbankAddonResponseEvent", msg);

								}
							}



							//if (msg.funcAction == 'RequireResetCustSignature') {
							if (msg.funcAction == 'GetUrlCustSignatureImage') {
								var tabs = require("sdk/tabs");
								for (let tab of tabs) {
									if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
										var reqTrackingArr = msg.reqContent.match("<custTrackingID>(.*)</custTrackingID>");
										var trackingID = reqTrackingArr[1]; //'20824';//
										var reqBookingArr = msg.reqContent.match("<custBookID>(.*)</custBookID>");
										var bookingID = reqBookingArr[1]; //'43';//
										var tmpScript = CFG_OBJ.EC_Iframe_Over_Fcc_Script;
										tmpScript = regReplace(tmpScript, CFG_OBJ.EC_Username_Key, CFG_OBJ.FCC_User);
										tmpScript = regReplace(tmpScript, CFG_OBJ.EC_Cust_TrackingID_Key, trackingID);
										tmpScript = regReplace(tmpScript, CFG_OBJ.EC_Cust_BookingID_Key, bookingID);

										tmpScript = regReplace(tmpScript, CFG_OBJ.EC_Iframe_Fcc_Url_Key, Common.getBaseUrl(CFG_OBJ.EC_Url) + msg.respResult);
										Common.logInfo('HuyNT2123 signature script: ' + tmpScript);
										tab.attach({
											contentScript: tmpScript
										});
									}
								}
							}
							else if (msg.funcAction == 'MarkCurrentTransComplete' || msg.funcAction == 'MarkCompleteServing') {
								var tabs = require("sdk/tabs");
								for (let tab of tabs) {
									if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
										tab.attach({
											contentScript: CFG_OBJ.EC_Clean_Iframe_Fcc_Script
										});
									}
								}
							}
							else if (msg.funcAction == 'PrintPDFFile') {
								var divTarget;
								var iframeTarget;
								var searchStatus = false;
								var docContent;
								var tabs = require("sdk/tabs");

								for (let tab of tabs) {
									if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
										var wd = getTabContentWindow(getTabForId(tab.id));
										docContent = wd.document;
									}
								}
								var fccFuncID = docContent.getElementById('fastpath').value;

								var divLauncher = docContent.getElementById('IFlauncher');
								var arrDivIframes = divLauncher.getElementsByTagName('div');
								Common.logInfo("FCC PRINT NODE 1: ");
								for (let tmpDivIframe of arrDivIframes) {
									var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
									if (arrIframes && arrIframes.length > 0) {
										var tmpIframe = arrIframes[0];
										var tmpIframeScr = tmpIframe.getAttribute('src');
										if ((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=' + fccFuncID) != -1)) {
											divTarget = tmpDivIframe;
											iframeTarget = tmpIframe;
											searchStatus = true;
											break;
										}
									}
								}
								if (searchStatus) {
									var docIframe = iframeTarget.contentDocument;
									Common.logInfo("FCC PRINT NODE 1.1: ");
									var tmpFCCFuncPrintArr = CFG_OBJ.FCC_Func_Print_Directly.split("#");
									var FCCFuncKey = "";
									Common.logInfo("FCC PRINT NODE 1.2: ");
									for (var i = 0; i < tmpFCCFuncPrintArr.length; i++) {
										var tmpFCCFuncCode = tmpFCCFuncPrintArr[i];
										Common.logInfo("FCC PRINT NODE 1.3: ");
										if (tmpFCCFuncCode && tmpFCCFuncCode.length > 0 && (fccFuncID == tmpFCCFuncCode)) {
											Common.logInfo("FCC PRINT NODE 2: " + tmpFCCFuncCode);
											FCCFuncKey = tmpFCCFuncCode;
											break;
										}
									}
									if (FCCFuncKey.length > 1) {
										Common.logInfo("FCC PRINT NODE 4: ");
										var urlPrintDirectly = CFG_OBJ.FCC_Func_Print_Directly_Url;
										urlPrintDirectly = regReplace(urlPrintDirectly, "___FCC_EC_FUNC_KEY___", FCCFuncKey);
										var tmpXREFNodeArr = CFG_OBJ.FCC_Func_Print_XREF_Node.split("#");
										Common.logInfo("FCC PRINT NODE 4: ");
										for (var i = 0; i < tmpXREFNodeArr.length; i++) {
											var tmpXREFNode = tmpXREFNodeArr[i];
											if (tmpXREFNode && tmpXREFNode.length > 0 && docIframe.getElementById(tmpXREFNode)) {
												urlPrintDirectly = regReplace(urlPrintDirectly, "___FCC_EC_TRANS_XREF___", docIframe.getElementById(tmpXREFNode).value);
												Common.logInfo("FCC PRINT URL: " + urlPrintDirectly);
												var tabsPrint = require("sdk/tabs");
												tabsPrint.open({
													url: urlPrintDirectly,
													inNewWindow: false
												});
												break;
											}
										}
									}
									else {
										Common.logInfo("FCC PRINT NODE 3: ");
										var tmpPrintNodeArr = CFG_OBJ.FCC_Print_VMS_nodeID.split("#");
										for (var i = 0; i < tmpPrintNodeArr.length; i++) {
											var tmpPrintNode = tmpPrintNodeArr[i];
											if (tmpPrintNode && tmpPrintNode.length > 0 && docIframe.getElementById(tmpPrintNode)) {
												Common.logInfo("FCC PRINT NODE 3.1: ");
												docIframe.getElementById(tmpPrintNode).click();
												break;
											}
										}
									}

									/*if(docIframe.getElementById("BLK_CUST_DETAILS__BTN_ADVICE")) {
										docIframe.getElementById("BLK_CUST_DETAILS__BTN_ADVICE").click();
									}
									else {
										docIframe.getElementById("BLK_TRANSACTION_DETAILS__BTN_ADVICE").click();
									}*/
								}
							} else if (msg.funcAction == 'ExportCardHelpReceipt') {
								setTimeout(function (e) {
									var tabs = require("sdk/tabs");
									tabs.open(msg.respResult);

								}, 2000);


							}

						}
					});

				}


				reqECService.post();

			}



		});

		worker.port.on("tpbankFreqGetStatusEvent", function (msg) {

			msg.script = Common.removeAccentff(msg.script);

			if (msg.scriptfile && msg.scriptfile.length > 1) {
				logInfoToFile("add-on script got the message tpbankFreqGetStatusEvent: " + Common.stringFromJSONObj(msg) + "\n FILE SCRIPT CONTENT: \n" + self.data.load(msg.scriptfile) + "\n", msg.logfile);
			}
			else {
				logInfoToFile("add-on script got the message tpbankFreqGetStatusEvent: " + Common.stringFromJSONObj(msg), msg.logfile);
			}

			var tabs = require("sdk/tabs");
			for (let tab of tabs) {
				if (tab.url.indexOf(CFG_OBJ.FCC_Keyword) != -1) {
					logInfoToFile("add-on run script: " + Common.stringFromJSONObj(msg), msg.logfile);

					//worker.port.emit("tpbankAddonFireEvent", msg);
					if (msg.scriptfile && msg.scriptfile.length > 1) {
						tab.attach({
							contentScriptFile: self.data.url(msg.scriptfile)
						});
					}
					else {
						tab.attach({
							contentScript: msg.script
						});
					}
				}
			}
		});
	},
	onDetach: function (worker) {

	}
});

/*
	Common functions
*/

function logInfoToFile(inContent, inStatus) {
	if (inStatus && inStatus == "1") {
		var logFileName = Common.getLogFileNameCurDate();
		var curDate = new Date();
		var logDateTimeStr = Utils.createDateString(CONST_DATE_YYYYMMDD_CFG, curDate) + " " + Utils.createTimeString(curDate);
		Common.logInfo(logDateTimeStr + ": " + inContent);
		FileUlts.appendText(logFileName, logDateTimeStr + ": " + inContent);
	}
}

function getConfig() {

	//caont request server get ip server to get teller name

	//getIPServerFromEcoutnerPublic();

	FileUlts.createFolder(CONST_LOG_FILEPATH);

	FileUlts.saveFile(CONST_CONFIG_FILEPATH, CONST_CONFIG_NAME, Common.stringFromJSONObj(CFG_OBJ));

	/*
	//caont bỏ vì giờ lấy config trên server
	
	var tmpConfigText = FileUlts.readFile(CONST_CONFIG_FILEPATH, CONST_CONFIG_NAME);
	if (tmpConfigText && tmpConfigText.length > 1) {
		CFG_OBJ = Common.stringToJSONObj(tmpConfigText);
		CONST_TRACKING_TAB_URL = CFG_OBJ.FCC_Url;
		Common.logInfo("Url: " + CONST_TRACKING_TAB_URL);
	}
	else {
		FileUlts.saveFile(CONST_CONFIG_FILEPATH, CONST_CONFIG_NAME, Common.stringFromJSONObj(CFG_OBJ));
		
	}
*/

	//getIPServerFromEcoutnerPublic();
}



function getIPServerFromEcoutnerPublic() {
	var typeRequest = 'BOOKING';
	var version = '1.0.1';
	/*	
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.open('POST', 'http://10.1.14.20:8012/ECounterWebserviceVer5.asmx', true);
	
	
		// build SOAP request
		var sr =
			'<?xml version="1.0" encoding="utf-8"?>' +
			'soap:Envelope' + 
				'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
				//'xmlns:api="http://127.0.0.1/Integrics/Enswitch/API" ' +
				'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ' +
				'xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">' +
				 '<soapenv:Body>' +
					'<requestGetInforFromServer xmlns="http://tempuri.org/">' +				
					'<typeGuest>'+typeRequest+'</typeGuest>'
					'<versionClient>'+ version +'</versionClient>'+
					'</requestGetInforFromServer>' +
				'</soapenv:Body>' +
			'</soap:Envelope>';
			
			
		logInfoToFile("em da vao day  : " + CFG_OBJ.EC_Url, "1");
		
			xmlhttp.onreadystatechange = function () {
			if (xmlhttp.readyState == 4) {
				if (xmlhttp.status == 200) {
					logInfoToFile("em da vao day  ok  ", "1");
				}
			}
		}
		// Send the POST request
		xmlhttp.setRequestHeader("SOAPAction","\"http://tempuri.org/requestGetInforFromServer\"");
		xmlhttp.setRequestHeader('Content-Type', 'text/xml');
		xmlhttp.timeout = 20000;
		xmlhttp.send(sr);
		
		*/


	var sr =
		'<?xml version="1.0" encoding="utf-8"?>' +
		'soap:Envelope' +
		'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
		//'xmlns:api="http://127.0.0.1/Integrics/Enswitch/API" ' +
		'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ' +
		'xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">' +
		'<soapenv:Body>' +
		'<requestGetInforFromServer xmlns="http://tempuri.org/">' +
		'<typeGuest>' + typeRequest + '</typeGuest>' +
		'<versionClient>' + version + '</versionClient>' +
		'</requestGetInforFromServer>' +
		'</soapenv:Body>' +
		'</soap:Envelope>';
	logInfoToFile("Request  of service get user name :  " + sr, "1"); // + " FULL_RESPONSE: " + response.text
	logInfoToFile("Request  url :  " + CFG_OBJ.EC_Url, "1"); // + " FULL_RESPONSE: " + response.text
	var reqECService = Request({
		url: CFG_OBJ.EC_Url,
		contentType: "text/xml; charset=utf-8",
		headers: {
			"SOAPAction": "http://tempuri.org/requestGetInforFromServer"
		},
		content: sr,
		onComplete: function (response) {
			if (response && response.text) {

				logInfoToFile("Response result of service get user name. ", "1"); // + " FULL_RESPONSE: " + response.text


			}

		}
	});
	reqECService.post();

	logInfoToFile("em da vao day  : 2 ", "1");


}


var Common = {
	logInfo: function (inContent) {
		if (!CONST_DEBUG_MODE) {
			return;
		}
		else {
			if (inContent == undefined) return;
			try {
				console.log(inContent);
			}
			catch (err) {
				console.log('error console.log: ' + err);
			}
		}
	},
	getLogFileNameCurDate: function () {
		var curDate = new Date();
		var curDateStr = Utils.createDateString(CONST_DATE_YYYYMMDD_CFG, curDate);
		return CONST_LOG_FILENAME + "-" + curDateStr + ".log"
	},
	stringFromJSONObj: function (inObj) {
		return JSON.stringify(inObj);
	},
	stringToJSONObj: function (inStr) {
		try {
			var tmpObj = JSON.parse(inStr);
			return tmpObj;
		}
		catch (ex) {
			Common.logInfo("--- EXCEPTION: Parser string to JSON object ---");
			Common.logInfo(ex);
			return undefined;
		}
	},
	removeAccentff: function (sText) {
		var sNewText = new String(sText);
		sNewText = regReplace(sNewText, "&quot;", '"');
		sNewText = regReplace(sNewText, "&lt;br /&gt;", "<br>");
		sNewText = regReplace(sNewText, "&amp;&nbsp;", " ");
		sNewText = regReplace(sNewText, "&lt;", "<");
		sNewText = regReplace(sNewText, "&gt;", ">");

		sNewText = regReplace(sNewText, "&nbsp;", " ");
		sNewText = regReplace(sNewText, "&iexcl;", "i");
		sNewText = regReplace(sNewText, "&macr;", "-");
		sNewText = regReplace(sNewText, "&ordf", "a");
		sNewText = regReplace(sNewText, "&plusmn;", "+|-");
		sNewText = regReplace(sNewText, "&sup1;", "1");
		sNewText = regReplace(sNewText, "&sup2;", "2");
		sNewText = regReplace(sNewText, "&sup3;", "3");
		sNewText = regReplace(sNewText, "&ordm", "0");
		sNewText = regReplace(sNewText, "&raquo", "»");
		sNewText = regReplace(sNewText, "&frac14", "1/4");
		sNewText = regReplace(sNewText, "&frac12", "1/2");
		sNewText = regReplace(sNewText, "&frac34", "3/4");
		sNewText = regReplace(sNewText, "&times;", "x");
		sNewText = regReplace(sNewText, "&divide;", "÷");
		sNewText = regReplace(sNewText, "&Agrave;", "À");
		sNewText = regReplace(sNewText, "&Aacute;", "Á");
		sNewText = regReplace(sNewText, "&Acirc;", "Â");
		sNewText = regReplace(sNewText, "&Atilde;", "Ã");
		sNewText = regReplace(sNewText, "&Auml;", "Ä");
		sNewText = regReplace(sNewText, "&Aring;", "Å");
		sNewText = regReplace(sNewText, "&AElig;", "Æ");
		sNewText = regReplace(sNewText, "&Ccedil;", "Ç");
		sNewText = regReplace(sNewText, "&Egrave;", "È");
		sNewText = regReplace(sNewText, "&Eacute;", "É");
		sNewText = regReplace(sNewText, "&Ecirc;", "Ê");
		sNewText = regReplace(sNewText, "&Euml;", "Ë");
		sNewText = regReplace(sNewText, "&Igrave;", "Ì");
		sNewText = regReplace(sNewText, "&Iacute;", "Í");
		sNewText = regReplace(sNewText, "&Icirc;", "Î");
		sNewText = regReplace(sNewText, "&Iuml;", "Ï");
		sNewText = regReplace(sNewText, "&ETH;", "Ð");
		sNewText = regReplace(sNewText, "&Ntilde;", "Ñ");
		sNewText = regReplace(sNewText, "&Ograve;", "Ò");
		sNewText = regReplace(sNewText, "&Oacute;", "Ó");
		sNewText = regReplace(sNewText, "&Ocirc;", "Ô");
		sNewText = regReplace(sNewText, "&Otilde;", "Õ");
		sNewText = regReplace(sNewText, "&Ouml;", "Ö");
		sNewText = regReplace(sNewText, "&Oslash;", "Ø");
		sNewText = regReplace(sNewText, "&Ugrave;", "Ù");
		sNewText = regReplace(sNewText, "&Uacute;", "Ú");
		sNewText = regReplace(sNewText, "&Ucirc;", "Û");
		sNewText = regReplace(sNewText, "&Uuml;", "Ü");
		sNewText = regReplace(sNewText, "&Yacute;", "Ý");
		sNewText = regReplace(sNewText, "&THORN;", "Þ");
		sNewText = regReplace(sNewText, "&szlig;", "ß");
		sNewText = regReplace(sNewText, "&agrave;", "à");
		sNewText = regReplace(sNewText, "&aacute;", "á");
		sNewText = regReplace(sNewText, "&acirc;", "â");
		sNewText = regReplace(sNewText, "&atilde;", "ã");
		sNewText = regReplace(sNewText, "&auml;", "ä");
		sNewText = regReplace(sNewText, "&aring;", "å");
		sNewText = regReplace(sNewText, "&aelig;", "æ");
		sNewText = regReplace(sNewText, "&ccedil;", "ç");
		sNewText = regReplace(sNewText, "&egrave;", "è");
		sNewText = regReplace(sNewText, "&eacute;", "é");
		sNewText = regReplace(sNewText, "&ecirc;", "ê");
		sNewText = regReplace(sNewText, "&euml;", "ë");
		sNewText = regReplace(sNewText, "&igrave;", "ì");
		sNewText = regReplace(sNewText, "&iacute;", "í");
		sNewText = regReplace(sNewText, "&icirc;", "î");
		sNewText = regReplace(sNewText, "&iuml;", "ï");
		sNewText = regReplace(sNewText, "&eth;", "ð");
		sNewText = regReplace(sNewText, "&ntilde;", "ñ");
		sNewText = regReplace(sNewText, "&ograve;", "ò");
		sNewText = regReplace(sNewText, "&oacute;", "ó");
		sNewText = regReplace(sNewText, "&ocirc;", "ô");
		sNewText = regReplace(sNewText, "&otilde;", "õ");
		sNewText = regReplace(sNewText, "&oslash;", "ø");
		sNewText = regReplace(sNewText, "&ugrave;", "ù");
		sNewText = regReplace(sNewText, "&uacute;", "ú");
		sNewText = regReplace(sNewText, "&ucirc;", "û");
		sNewText = regReplace(sNewText, "&uuml;", "ü");
		sNewText = regReplace(sNewText, "&yacute;", "ý");
		sNewText = regReplace(sNewText, "&thorn;", "þ");
		sNewText = regReplace(sNewText, "&yuml;", "ÿ");
		sNewText = regReplace(sNewText, "&amp;", '&');
		sNewText = regReplace(sNewText, "&amp;ecirc;", "ê");
		sNewText = regReplace(sNewText, "&amp;aacute;", "á");
		sNewText = regReplace(sNewText, "&amp;oacute;", "ó");
		sNewText = regReplace(sNewText, "&amp;atilde;", "ã");
		sNewText = regReplace(sNewText, "&amp;agrave;", "à");
		sNewText = regReplace(sNewText, "&amp;ocirc;", "ô");
		sNewText = regReplace(sNewText, "&amp;igrave;", "ì");
		sNewText = regReplace(sNewText, "&amp;Agrave;", "À");
		sNewText = regReplace(sNewText, "&amp;Aacute;", "Á");
		sNewText = regReplace(sNewText, "&amp;Acirc;", "Â");
		sNewText = regReplace(sNewText, "&amp;Atilde;", "Ã");
		sNewText = regReplace(sNewText, "&amp;Auml;", "Ä");
		sNewText = regReplace(sNewText, "&amp;Aring;", "Å");
		sNewText = regReplace(sNewText, "&amp;AElig;", "Æ");
		sNewText = regReplace(sNewText, "&amp;Egrave;", "È");
		sNewText = regReplace(sNewText, "&amp;Ccedil;", "Ç");
		sNewText = regReplace(sNewText, "&amp;Eacute;", "É");
		sNewText = regReplace(sNewText, "&amp;Ecirc;", "Ê");
		sNewText = regReplace(sNewText, "&amp;Euml;", "Ë");
		sNewText = regReplace(sNewText, "&amp;Igrave;", "Ì");
		sNewText = regReplace(sNewText, "&amp;&Iacute;", "Í");
		sNewText = regReplace(sNewText, "&amp;&Icirc;", "Î");
		sNewText = regReplace(sNewText, "&amp;&Iuml;", "Ï");
		sNewText = regReplace(sNewText, "&amp;&ETH;", "Ð");
		sNewText = regReplace(sNewText, "&amp;&Ntilde;", "Ñ");
		sNewText = regReplace(sNewText, "&amp;&Ograve;", "Ò");
		sNewText = regReplace(sNewText, "&amp;&Oacute;", "Ó");
		sNewText = regReplace(sNewText, "&amp;&Ocirc;", "Ô");
		sNewText = regReplace(sNewText, "&amp;&Otilde;", "Õ");
		sNewText = regReplace(sNewText, "&amp;&Ouml;", "Ö");
		sNewText = regReplace(sNewText, "&amp;&Oslash;", "Ø");
		sNewText = regReplace(sNewText, "&amp;&Ugrave;", "Ù");
		sNewText = regReplace(sNewText, "&amp;&Uacute;", "Ú");
		sNewText = regReplace(sNewText, "&amp;&Ucirc;", "Û");
		sNewText = regReplace(sNewText, "&amp;&Uuml;", "Ü");
		sNewText = regReplace(sNewText, "&amp;&Yacute;", "Ý");
		sNewText = regReplace(sNewText, "&amp;&THORN;", "Þ");
		sNewText = regReplace(sNewText, "&amp;&szlig;", "ß");
		sNewText = regReplace(sNewText, "&amp;&acirc;", "â");
		sNewText = regReplace(sNewText, "&amp;&auml;", "ä");
		sNewText = regReplace(sNewText, "&amp;&aring;", "å");
		sNewText = regReplace(sNewText, "&amp;&aelig;", "æ");
		sNewText = regReplace(sNewText, "&amp;&ccedil;", "ç");
		sNewText = regReplace(sNewText, "&amp;&egrave;", "è");
		sNewText = regReplace(sNewText, "&amp;&eacute;", "é");
		sNewText = regReplace(sNewText, "&amp;&euml;", "ë");
		sNewText = regReplace(sNewText, "&amp;&igrave;", "ì");
		sNewText = regReplace(sNewText, "&amp;&iacute;", "í");
		sNewText = regReplace(sNewText, "&amp;&icirc;", "î");
		sNewText = regReplace(sNewText, "&amp;&iuml;", "ï");
		sNewText = regReplace(sNewText, "&amp;&eth;", "ð");
		sNewText = regReplace(sNewText, "&amp;&ntilde;", "ñ");
		sNewText = regReplace(sNewText, "&amp;&ograve;", "ò");
		sNewText = regReplace(sNewText, "&amp;&otilde;", "õ");
		sNewText = regReplace(sNewText, "&amp;&oslash;", "ø");
		sNewText = regReplace(sNewText, "&amp;&ugrave;", "ù");
		sNewText = regReplace(sNewText, "&amp;&uacute;", "ú");
		sNewText = regReplace(sNewText, "&amp;&ucirc;", "û");
		sNewText = regReplace(sNewText, "&amp;&uuml;", "ü");
		sNewText = regReplace(sNewText, "&amp;&yacute;", "ý");
		sNewText = regReplace(sNewText, "&amp;&thorn;", "þ");
		sNewText = regReplace(sNewText, "&amp;&yuml;", "ÿ");
		return sNewText;

	},
	getBaseUrl: function (inUrl) {
		var re = new RegExp(/^.*\//);
		return re.exec(inUrl);
	}
}

function regReplace(sInput, sReg, sNew) {
	var re = new RegExp(sReg, "g");
	return sInput.replace(re, sNew);
}

/*
	Write to file
*/
const { pathFor } = require('sdk/system');
const pathSaveFile = require('sdk/fs/path');
const fileAddonUsing = require('sdk/io/file');
var { Cc, Ci, Cu } = require("chrome");
let FileUtils = Cu.import("resource://gre/modules/FileUtils.jsm");

var FileUlts = {
	createFolder: function (inPath) {
		fileAddonUsing.mkpath(inPath);
	},
	appendText: function (name, str) {
		/*var filename = pathSaveFile.join(pathFor('ProfD'), name);*/
		/*var dir = FileUtils.getDir("C:\\", ["DIR"], true);*/
		var filename = pathSaveFile.join(CONST_LOG_FILEPATH, name);
		if (!fileAddonUsing.exists(filename)) {
			var textWriter = fileAddonUsing.open(filename, 'w');
			textWriter.write(str);
			textWriter.close();
		}
		else {
			var textReader = fileAddonUsing.open(filename, 'r');
			var tmpFileContent = textReader.read();
			textReader.close();

			var textWriter = fileAddonUsing.open(filename, 'w');
			textWriter.write(tmpFileContent + "\n\n" + str);
			textWriter.close();
		}
	},

	saveText: function (name, str) {
		/*var filename = pathSaveFile.join(pathFor('ProfD'), name);*/
		var filename = pathSaveFile.join(CONST_LOG_FILEPATH, name);
		var textWriter = fileAddonUsing.open(filename, 'w');
		textWriter.write(str);
		textWriter.close();
	},
	saveFile: function (fpath, fname, str) {
		/*var filename = pathSaveFile.join(pathFor('ProfD'), name);*/
		var filename = pathSaveFile.join(fpath, fname);
		var textWriter = fileAddonUsing.open(filename, 'w');
		textWriter.write(str);
		textWriter.close();
	},
	readText: function (name) {
		/*var filename = pathSaveFile.join(pathFor('ProfD'), name);*/
		var filename = pathSaveFile.join(CONST_LOG_FILEPATH, name);
		if (!fileAddonUsing.exists(filename)) {
			return null;
		}
		var textReader = fileAddonUsing.open(filename, 'r');
		var str = textReader.read();
		textReader.close();
		return str;
	},
	readFile: function (fpath, fname) {
		/*var filename = pathSaveFile.join(pathFor('ProfD'), name);*/
		var filename = pathSaveFile.join(fpath, fname);
		if (!fileAddonUsing.exists(filename)) {
			return null;
		}
		var textReader = fileAddonUsing.open(filename, 'r');
		var str = textReader.read();
		textReader.close();
		return str;
	}
}

var notificationsCustComing = require("sdk/notifications");
notificationsCustComing.notify({
	title: "TPBank Auto-FCC",
	text: "'EBank team - Have a nice day",
	data: "Have a nice day",
	onClick: function (data) {
		console.log(data);
	}
});
// a dummy function, to show how tests work.
// to see how to test this function, look at test/test-index.js
function dummy(text, callback) {
	callback(text);
}

exports.dummy = dummy;
