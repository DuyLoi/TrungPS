cd /Users/ebankretail/addon
/Users/ebankretail/node_modules/jpm/bin/jpm xpi