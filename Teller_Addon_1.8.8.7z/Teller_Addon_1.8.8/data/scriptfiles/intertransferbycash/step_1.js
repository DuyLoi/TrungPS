var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=1460') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value = '___FCC_INTERTRANS_CASH_GL_NO___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').value = '___FCC_INTERTRANS_CASH_GL_DES_CURRENCY___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = '___FCC_INTERTRANS_CASH_GL_SOU_CURRENCY___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value = '___FCC_INTERTRANS_CASH_AMOUNT___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').value = '___FCC_INTERTRANS_CASH_CONTENT___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').innerHTML = '___FCC_INTERTRANS_CASH_CONTENT___';
	
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent("onchange");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').fireEvent("onchange");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').fireEvent("onchange");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').fireEvent("onchange");
	}
	/*
	docIframe.getElementById('New').getElementsByTagName('a')[0].click();
	setTimeout(function(){
		var docBrnAlert = docIframe.getElementById('ifrSubScreen').contentDocument;
		//docBrnAlert.getElementById('branchId').getElementsByTagName('input')[0].value = '___FCC_INTERTRANS_BRN_CODE___';
		docBrnAlert.getElementById('BTN_OK').click();
	}, 500);
	*/
	/*docIframe.getElementById('BTN_OK').click();*/
}