document.getElementById('fastpath').value = '8004';
document.getElementById('btnGo').click();