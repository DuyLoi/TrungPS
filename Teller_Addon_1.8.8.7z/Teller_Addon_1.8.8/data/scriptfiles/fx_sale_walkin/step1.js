document.getElementById('fastpath').value = '8203';
document.getElementById('btnGo').click();