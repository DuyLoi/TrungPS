var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if(tmpIframeScr.indexOf('funcid=STDCIF') != -1) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
    var docIframe = iframeTarget.contentDocument;
    docIframe.getElementById('EnterQuery').getElementsByTagName('a')[0].click();
    setTimeout(function(){
		docIframe.getElementById('BLK_CUSTOMER__CUSTNO').value = '___FCC_CUSTOMER_NO___';
		if ('createEvent' in document) {
			var evt = document.createEvent('HTMLEvents');
			evt.initEvent('change', false, true);
			docIframe.getElementById('BLK_CUSTOMER__CUSTNO').dispatchEvent(evt);
		}
		else {
			docIframe.getElementById('BLK_CUSTOMER__CUSTNO').fireEvent('onchange');
        }
        setTimeout(function(){
            docIframe.getElementById('ExecuteQuery').getElementsByTagName('a')[0].click();
				setTimeout(function(){
					docIframe.getElementById('Unlock').getElementsByTagName('a')[0].click();
				}, 500);
        }, 200);
	}, 200);
}