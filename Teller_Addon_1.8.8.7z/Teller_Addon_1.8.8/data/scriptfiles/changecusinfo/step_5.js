var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if (tmpIframeScr.indexOf('funcid=STDCIF') != -1) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}
	}
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	var registerSMS = '___FCC_CUSTPERSONAL__REGISTER_SMS___';
	var nationality = '___FCC_CUSTOMER__NLTY___';
	if (nationality == 'Vietnamese' || nationality == 'Việt Nam') {
		docIframe.getElementById('BLK_CUSTOMER__NLTY').value = 'VN';
	} else {
		docIframe.getElementById('BLK_CUSTOMER__NLTY').value = nationality;
	}
	docIframe.getElementById('BLK_CUSTOMER__FULLNAME').value = '___FCC_CUSTOMER__FULLNAME___';
	docIframe.getElementById('BLK_CUSTOMER__SNAME').value = '___FCC_CUSTOMER__SNAME___';
	docIframe.getElementById('BLK_CUSTPERSONAL__FSTNAME').value = '___FCC_CUSTPERSONAL__FSTNAME___';
	docIframe.getElementById('BLK_CUSTPERSONAL__MIDNAME').value = '___FCC_CUSTPERSONAL__MIDNAME___';
	docIframe.getElementById('BLK_CUSTPERSONAL__LSTNAME').value = '___FCC_CUSTPERSONAL__LSTNAME___';
	docIframe.getElementById('BLK_CUSTPERSONAL__PADD1').value = '___FCC_CUSTPERSONAL__PADD1___';
	docIframe.getElementById('BLK_CUSTPERSONAL__PADD2').value = '___FCC_CUSTPERSONAL__PADD2___';
	docIframe.getElementById('BLK_CUSTPERSONAL__PADD3').value = '___FCC_CUSTPERSONAL__PADD3___';
	docIframe.getElementById('BLK_CUSTPERSONAL__PADD4').value = '___FCC_CUSTPERSONAL__PADD4___';
	docIframe.getElementById('BLK_CUSTOMER__ADDRLN1').value = '___FCC_CUSTOMER__ADDRLN1___';
	docIframe.getElementById('BLK_CUSTOMER__ADDRLN2').value = '___FCC_CUSTOMER__ADDRLN2___';
	docIframe.getElementById('BLK_CUSTOMER__ADDRLN3').value = '___FCC_CUSTOMER__ADDRLN3___';
	docIframe.getElementById('BLK_CUSTOMER__ADDRLN4').value = '___FCC_CUSTOMER__ADDRLN4___';
	docIframe.getElementById('BLK_CUSTPERSONAL__MOBNUM').value = '___FCC_CUSTPERSONAL__MOBNUM___';
	docIframe.getElementById('BLK_CUSTPERSONAL__EMAIL').value = '___FCC_CUSTPERSONAL__EMAIL___';

	if (registerSMS == 1) {
		docIframe.getElementById('BLK_CUSTPERSONAL__CUST_COMM_MODE2').click();
	} else {
		docIframe.getElementById('BLK_CUSTPERSONAL__CUST_COMM_MODE').click();
	}
	if ('createEvent' in document) {
		var evt = document.createEvent('HTMLEvents');
		evt.initEvent('change', false, true);
		docIframe.getElementById('BLK_CUSTOMER__FULLNAME').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__SNAME').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__FSTNAME').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__MIDNAME').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__LSTNAME').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__NLTY').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD1').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD2').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD3').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD4').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN1').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN2').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN3').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN4').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTPERSONAL__MOBNUM').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_CUSTOMER__FULLNAME').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__SNAME').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__FSTNAME').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__MIDNAME').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__LSTNAME').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__NLTY').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD1').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD2').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD3').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__PADD4').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN1').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN2').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN3').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__ADDRLN4').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTPERSONAL__MOBNUM').fireEvent('onchange');
	}
}