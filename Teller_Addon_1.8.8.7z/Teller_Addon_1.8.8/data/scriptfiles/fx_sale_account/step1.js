document.getElementById('fastpath').value = '8206';
document.getElementById('btnGo').click();