/**
 * Created by HuyNT2.
 * User:
 * Date: 21/04/2015
 * Time: 5:35 PM
 */


var doc=document.getElementById('ifrSubScreen').contentDocument; 
doc.getElementById('1').value='011'; 
doc.getElementById('LOVPageHead').getElementsByClassName('BTNtext')[0].click();
