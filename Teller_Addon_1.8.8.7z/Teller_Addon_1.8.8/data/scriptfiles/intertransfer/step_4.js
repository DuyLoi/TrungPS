var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=DEDRTTLR') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	var docIframeSubScr = docIframe.getElementById('ifrSubScreen').contentDocument;
	
	docIframeSubScr.getElementById('BLK_SETLEDETAILS__ACC_WITH_INSTN1').value = '___FCC_INTERTRANS_CITAD_CODE___';
	//docIframeSubScr.getElementById('BLK_SETLEDETAILS__ACC_WITH_INSTN2').value = '___FCC_INTERTRANS_CITAD_BANKNAME___';
	docIframeSubScr.getElementById('BLK_SETLEDETAILS__ORDERING_CUSTOMER1').value = '___FCC_INTERTRANS_SOU_ACC_NAME1___';
	docIframeSubScr.getElementById('BLK_SETLEDETAILS__ORDERING_CUSTOMER2').value = '___FCC_INTERTRANS_SOU_ACC_NAME2___';
	docIframeSubScr.getElementById('BLK_SETLEDETAILS__ULT_BENEFICIARY1').value = '___FCC_INTERTRANS_DES_ACC_NO___';
	docIframeSubScr.getElementById('BLK_SETLEDETAILS__ULT_BENEFICIARY2').value = '___FCC_INTERTRANS_DES_ACC_NAME___';
	docIframeSubScr.getElementById('BLK_SETLEDETAILS__PAYMENT_DETAILS1').value = '___FCC_INTERTRANS_TPB_CONTENT___';
	
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ACC_WITH_INSTN1').dispatchEvent(evt);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ACC_WITH_INSTN2').dispatchEvent(evt);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ORDERING_CUSTOMER1').dispatchEvent(evt);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ORDERING_CUSTOMER2').dispatchEvent(evt);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ULT_BENEFICIARY1').dispatchEvent(evt);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ULT_BENEFICIARY2').dispatchEvent(evt);
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__PAYMENT_DETAILS1').dispatchEvent(evt);
	}
	else {
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ACC_WITH_INSTN1').fireEvent("onchange");
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ACC_WITH_INSTN2').fireEvent("onchange");
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ORDERING_CUSTOMER1').fireEvent("onchange");
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ORDERING_CUSTOMER2').fireEvent("onchange");
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ULT_BENEFICIARY1').fireEvent("onchange");
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__ULT_BENEFICIARY2').fireEvent("onchange");
		docIframeSubScr.getElementById('BLK_SETLEDETAILS__PAYMENT_DETAILS1').fireEvent("onchange");
	}
	setTimeout(function(){
		docIframeSubScr.getElementById('BTN_OK').click();
	}, 500);
	
	/*docIframe.getElementById('BTN_OK').click();*/
}