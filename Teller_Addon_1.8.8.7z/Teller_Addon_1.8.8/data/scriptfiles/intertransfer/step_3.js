var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=DEDRTTLR') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_MAIN__REL_CUSTOMER').value = '___FCC_INTERTRANS_RELATED_CUST_NO___';
	docIframe.getElementById('BLK_MAIN__TXN_CCY').value = '___FCC_INTERTRANS_SOU_CURRENCY___';
	docIframe.getElementById('BLK_MAIN__TXN_BRANCH').value = '___FCC_INTERTRANS_SOU_BRN_CODE___';
	docIframe.getElementById('BLK_MAIN__TXN_ACC').value = '___FCC_INTERTRANS_SOU_ACC_NO___';
	docIframe.getElementById('BLK_MAIN__OFS_CCY').value = '___FCC_INTERTRANS_SOU_CURRENCY___';
	//docIframe.getElementById('BLK_MAIN__OFS_BRANCH').value = '___FCC_INTERTRANS_DES_BRN_CODE___';
	//docIframe.getElementById('BLK_MAIN__OFS_ACC').value = '___FCC_INTERTRANS_DES_ACC_NO___';
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframe.getElementById('BLK_MAIN__REL_CUSTOMER').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__TXN_CCY').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__TXN_BRANCH').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__TXN_ACC').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__OFS_CCY').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__OFS_BRANCH').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__OFS_ACC').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_MAIN__REL_CUSTOMER').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__TXN_CCY').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__TXN_BRANCH').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__TXN_ACC').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__OFS_CCY').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__OFS_BRANCH').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__OFS_ACC').fireEvent("onchange");
	}
	docIframe.getElementById('BLK_MAIN__TXN_AMOUNTI').value = '___FCC_INTERTRANS_AMOUNT___';
	docIframe.getElementById('BLK_MAIN__OFS_AMOUNTI').value = '___FCC_INTERTRANS_AMOUNT___';
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("blur", false, true);
		docIframe.getElementById('BLK_MAIN__TXN_AMOUNTI').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__OFS_AMOUNTI').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_MAIN__TXN_AMOUNTI').fireEvent("onblur");
		docIframe.getElementById('BLK_MAIN__OFS_AMOUNTI').fireEvent("onblur");
	}
	docIframe.getElementById('BLK_MAIN__NARRATIVE').value = '___FCC_INTERTRANS_TPB_CONTENT___';
	
	docIframe.getElementById('CVS_SETLDTLS').getElementsByTagName('a')[0].click();
	
	/*docIframe.getElementById('BTN_OK').click();*/
}