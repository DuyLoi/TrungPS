var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=DEDRTTLR') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_MAIN__ROUTE_CODE').value = '___FCC_INTERTRANS_ROUTE_CODE___';
	docIframe.getElementById('BLK_MAIN__PRODUCT_CODE').value = '___FCC_INTERTRANS_PRODUCT_CODE___';
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframe.getElementById('BLK_MAIN__ROUTE_CODE').dispatchEvent(evt);
		docIframe.getElementById('BLK_MAIN__PRODUCT_CODE').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_MAIN__ROUTE_CODE').fireEvent("onchange");
		docIframe.getElementById('BLK_MAIN__PRODUCT_CODE').fireEvent("onchange");
	}
	setTimeout(function(){
		docIframe.getElementById('BLK_MAIN__BTN_AUTOPOP').click();
		setTimeout(function(){
			var docBrnAlert = docIframe.getElementById('ifr_AlertWin').contentDocument;
			docBrnAlert.getElementById('BTN_OK').click();
		}, 900);
	}, 500);
	
	/*docIframe.getElementById('BTN_OK').click();*/
}