var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=TDMM') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_CUST_ACCOUNT__CUSTNO').value = '___FCC_OPEN_SAVING_CUSTNO___';
	docIframe.getElementById('BLK_CUST_ACCOUNT__CCY').value = '___FCC_OPEN_SAVING_CURRENCY___';
	docIframe.getElementById('BLK_CUST_ACCOUNT__ACCLS').value = '___FCC_OPEN_SAVING_ACC_CLASS___';
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframe.getElementById('BLK_CUST_ACCOUNT__CUSTNO').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUST_ACCOUNT__CCY').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUST_ACCOUNT__ACCLS').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_CUST_ACCOUNT__CUSTNO').fireEvent("onchange");
		docIframe.getElementById('BLK_CUST_ACCOUNT__CCY').fireEvent("onchange");
		docIframe.getElementById('BLK_CUST_ACCOUNT__ACCLS').fireEvent("onchange");
	}
	
	docIframe.getElementById('BLK_CUST_ACCOUNT__BTN_P').click();
	setTimeout(function(){
		docIframe.getElementById('cmdAddRow_BLK_TDPAYINDETAILS').click();
		setTimeout(function(){
			//S:ACCOUNT C:CASH G:TAI KHOAN TRUNG GIAN Q:CHEQUE
			docIframe.getElementById('BLK_TDPAYINDETAILS__MMPAYOPT').value = '___FCC_OPEN_SAVING_PAY_OPTION___';
			docIframe.getElementById('BLK_TDPAYINDETAILS__MMPERCENTAGEI').value = '100';
			docIframe.getElementById('BLK_TDPAYINDETAILS__MMTDOFFSETACC').value = '___FCC_OPEN_SAVING_PAYIN_ACC_NO___';
			if ("createEvent" in document) {
				var evt = document.createEvent("HTMLEvents");
				evt.initEvent("change", false, true);
				docIframe.getElementById('BLK_TDPAYINDETAILS__MMTDOFFSETACC').dispatchEvent(evt);
			}
			else {
				docIframe.getElementById('BLK_TDPAYINDETAILS__MMTDOFFSETACC').fireEvent("onchange");
			}
			docIframe.getElementById('BLK_TDDETAILS__TDAMTI').value = '___FCC_OPEN_SAVING_AMOUNT___';
			if ("createEvent" in document) {
				var evt = document.createEvent("HTMLEvents");
				evt.initEvent("blur", false, true);
				docIframe.getElementById('BLK_TDDETAILS__TDAMTI').dispatchEvent(evt);
				docIframe.getElementById('BLK_TDPAYINDETAILS__MMPERCENTAGEI').dispatchEvent(evt);
			}
			else {
				docIframe.getElementById('BLK_TDDETAILS__TDAMTI').fireEvent("onblur");
				docIframe.getElementById('BLK_TDPAYINDETAILS__MMPERCENTAGEI').fireEvent("onblur");
			}
			docIframe.getElementById('BLK_TDDETAILS__DEPTENORYEARSI').value = '___FCC_OPEN_SAVING_TENOR_YEARS___';
			docIframe.getElementById('BLK_TDDETAILS__DEPTENORMONSI').value = '___FCC_OPEN_SAVING_TENOR_MONTHS___';
			docIframe.getElementById('BLK_TDDETAILS__DEPTENORDAYSI').value = '___FCC_OPEN_SAVING_TENOR_DAYS___';
			if ("createEvent" in document) {
				var evt = document.createEvent("HTMLEvents");
				evt.initEvent("change", false, true);
				docIframe.getElementById('BLK_TDDETAILS__DEPTENORYEARSI').dispatchEvent(evt);
				docIframe.getElementById('BLK_TDDETAILS__DEPTENORMONSI').dispatchEvent(evt);
				docIframe.getElementById('BLK_TDDETAILS__DEPTENORDAYSI').dispatchEvent(evt);
			}
			else {
				docIframe.getElementById('BLK_TDDETAILS__DEPTENORYEARSI').fireEvent("onchange");
				docIframe.getElementById('BLK_TDDETAILS__DEPTENORMONSI').fireEvent("onchange");
				docIframe.getElementById('BLK_TDDETAILS__DEPTENORDAYSI').fireEvent("onchange");
			}
			//docIframe.getElementById('BLK_TDDETAILS__AUTOROLL').click();
			var rollStatus = '___FCC_OPEN_SAVING_AUTOROLL_STATUS___';
			var rollType = '___FCC_OPEN_SAVING_ROLL_TYPE_OPTION___'; //I: tai tuc ca goc + lai; P: tai tuc goc
			if(rollStatus == 'true') {
				docIframe.getElementById('BLK_TDDETAILS__AUTOROLL').checked = true;
			}
			else {
				docIframe.getElementById('BLK_TDDETAILS__AUTOROLL').checked = false;
			}
			docIframe.getElementById('BLK_TDDETAILS__ROLLTYPE').value = rollType;
			if(rollStatus != 'true' || (rollStatus == 'true' && rollType == 'P')) {
				docIframe.getElementById('cmdAddRow_BLK_TDPAYOUTDETAILS').click();
				setTimeout(function(){
					if(rollStatus != 'true') {
						//S:ACCOUNT G:TAI KHOAN TRUNG GIAN B:SEC
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PAYOUTTYPE').value = 'S';
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PERCENTAGEI').value = '100';
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__OFFACC').value = '___FCC_OPEN_SAVING_MATURITY_ACC___';
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PAYOUTCOMP').value = 'P';
						docIframe.getElementById('BLK_INTDETAILS__BOOKACC').value = '___FCC_OPEN_SAVING_MATURITY_ACC___';
					}
					if (rollStatus == 'true' && rollType == 'P') {
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PAYOUTTYPE').value = 'S';
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PERCENTAGEI').value = '100';
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__OFFACC').value = '___FCC_OPEN_SAVING_MATURITY_ACC___';
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PAYOUTCOMP').value = 'I';
						docIframe.getElementById('BLK_INTDETAILS__BOOKACC').value = '___FCC_OPEN_SAVING_MATURITY_ACC___';
					}
					if ("createEvent" in document) {
						var evt = document.createEvent("HTMLEvents");
						evt.initEvent("change", false, true);
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__OFFACC').dispatchEvent(evt);
						docIframe.getElementById('BLK_INTDETAILS__BOOKACC').dispatchEvent(evt);
						var evt1 = document.createEvent("HTMLEvents");
						evt1.initEvent("blur", false, true);
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PERCENTAGEI').dispatchEvent(evt1);
					}
					else {
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__OFFACC').fireEvent("onchange");
						docIframe.getElementById('BLK_INTDETAILS__BOOKACC').fireEvent("onchange");
						docIframe.getElementById('BLK_TDPAYOUTDETAILS__PERCENTAGEI').fireEvent("onblur");
					}
				}, 500);
			}
		}, 500);
	}, 1000);
	
	/*docIframe.getElementById('BTN_OK').click();*/
}