var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=1401') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value = '___FCC_CASH_DEPOSIT_ACCOUNT___';
	if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("change", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt);
		}
		else
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent("onchange");
	
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = '___FCC_CASH_DEPOSIT_CURRENCY___';
	if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("change", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').dispatchEvent(evt);
		}
		else
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').fireEvent("onchange");
	
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value = '___FCC_CASH_DEPOSIT_AMOUNT___';
	setTimeout(function(){
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').value = '___FCC_CASH_DEPOSIT_NARRATIVE___';
		
		if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("blur", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').dispatchEvent(evt);
		}
		else
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').fireEvent("onblur");
	}, 200);
	
	/*docIframe.getElementById('BTN_OK').click();*/
}