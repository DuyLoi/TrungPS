var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=1317') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	//N: rut toan bo stk, Y: rut 1 phan stk
	var redemType = '___FCC_WITHDRAW_SAVING_REDEM_TYPE___';
	docIframe.getElementById('BLK_TD_REDEMPTION__REDEMPTION_MODE').value = redemType;
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframe.getElementById('BLK_TD_REDEMPTION__REDEMPTION_MODE').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_TD_REDEMPTION__REDEMPTION_MODE').fireEvent("onchange");
	}
	setTimeout(function(){
		docIframe.getElementById('BLK_TD_REDEMPTION__REDEMPTION_AMTI').value = '___FCC_WITHDRAW_SAVING_AMOUNT___';
		if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("blur", false, true);
			docIframe.getElementById('BLK_TD_REDEMPTION__REDEMPTION_AMTI').dispatchEvent(evt);
		}
		else {
			docIframe.getElementById('BLK_TD_REDEMPTION__REDEMPTION_AMTI').fireEvent("onblur");
		}
	}, 500);
	
	docIframe.getElementById('cmdAddRow_BLK_TDREDMPAYOUT_DETAILS').click();
	setTimeout(function(){
		//S: qua tai khoan, C: bang tien
		docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__PAYOUTTYPE').value = '___FCC_WITHDRAW_SAVING_PAYOUT_TYPE___';
		docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI').value = '100';
		docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__OFFSET_ACC').value = '___FCC_WITHDRAW_SAVING_DEST_ACC___';
		if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("change", false, true);
			docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__OFFSET_ACC').dispatchEvent(evt);
			var evt1 = document.createEvent("HTMLEvents");
			evt1.initEvent("blur", false, true);
			docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI').dispatchEvent(evt1);
		}
		else {
			docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__OFFSET_ACC').fireEvent("onchange");
			docIframe.getElementById('BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI').fireEvent("onchange");
		}
	}, 500);
	
	/*docIframe.getElementById('BTN_OK').click();*/
}