var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('Div_ChildWin');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('TxnBranch.jsp') != -1) && (tmpIframeScr.indexOf('funcid=1317') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	//docIframe.getElementById('TXTstd').value = '___FCC_WITHDRAW_SAVING_BRN_CODE___';
	//docIframe.getElementById('BTN_OK').click();
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("click", false, true);
		docIframe.getElementById('BTN_OK').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BTN_OK').fireEvent("onclick");
	}
	/*docIframe.getElementById('BTN_OK').click();*/
}