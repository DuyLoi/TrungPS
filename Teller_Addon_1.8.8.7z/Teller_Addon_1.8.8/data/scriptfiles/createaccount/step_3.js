var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if (tmpIframeScr.indexOf('funcid=STDCIF') != -1) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}
	}
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_CUSTOMER__UDF1').value = '___FCC_CUSTOMER__UIDVAL___';
	docIframe.getElementById('BLK_CUSTOMER__UDF2').value = '___FCC_CUSTOMER__DATE_ISSUE___';
	docIframe.getElementById('BLK_CUSTOMER__UDF3').value = '___FCC_CUSTOMER__PLACE_ISSUE___';
	docIframe.getElementById('BLK_CUSTOMER__UDF4').value = '___FCC_CUSTOMER__TEL_MOBILE___';
	if ('createEvent' in document) {
		var evt = document.createEvent('HTMLEvents');
		evt.initEvent('change', false, true);
		docIframe.getElementById('BLK_CUSTOMER__UDF1').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__UDF2').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__UDF3').dispatchEvent(evt);
		docIframe.getElementById('BLK_CUSTOMER__UDF4').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_CUSTOMER__UDF1').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__UDF2').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__UDF3').fireEvent('onchange');
		docIframe.getElementById('BLK_CUSTOMER__UDF4').fireEvent('onchange');
	}
	setTimeout(function () {
		docIframe.getElementById('TAB_ADDITIONAL').click();
	}, 500);
}