document.getElementById('fastpath').value = 'STDCIF';
document.getElementById('btnGo').click();