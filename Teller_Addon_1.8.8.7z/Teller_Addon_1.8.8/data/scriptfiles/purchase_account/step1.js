document.getElementById('fastpath').value = '8207';
document.getElementById('btnGo').click();