var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if(tmpIframeScr.indexOf('funcid=8207') != -1) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
    var docIframe = iframeTarget.contentDocument;
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__BENFNAME').value = '___FCC_TRANSACTION_DETAILS__BENFNAME___';
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__OTHERDETLS1').value = '___FCC_TRANSACTION_DETAILS__CMND___';
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value = '___FCC_TRANSACTION_DETAILS__AMOUNT_BOUGHT___';
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = '___FCC_TRANSACTION_DETAILS__CURRENCY_BOUGHT___';
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value = '___FCC_TRANSACTION_DETAILS__ACCOUNT___';
    if ('createEvent' in document) {
		var evt = document.createEvent('HTMLEvents');
		evt.initEvent('change', false, true);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__BENFNAME').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OTHERDETLS1').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt);
	}
	else {
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__BENFNAME').fireEvent('onchange');
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OTHERDETLS1').fireEvent('onchange');
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').fireEvent('onchange');
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').fireEvent('onchange');
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent('onchange');
	}
}