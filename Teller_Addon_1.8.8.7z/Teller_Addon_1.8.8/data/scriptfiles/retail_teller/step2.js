var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if (tmpIframeScr.indexOf('funcid=DEDRTTLR') != -1) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}
	}
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('New').getElementsByTagName('a')[0].click();
	setTimeout(function () {
		var iframe2 = docIframe.getElementById('ifrSubScreen');
		var contentIframe2 = iframe2.contentDocument;
		contentIframe2.getElementById('BTN_OK').click();
		setTimeout(function () {
			docIframe.getElementById('BLK_MAIN__TXN_ACC').value = '___FCC_MAIN__TXN_ACC___';
			docIframe.getElementById('BLK_MAIN__OFS_ACC').value = '___FCC_MAIN__OFS_ACC___';
			docIframe.getElementById('BLK_MAIN__OFS_CCY').value = '___FCC_MAIN__OFS_CCY___';
			docIframe.getElementById('BLK_MAIN__OFS_AMOUNTI').value = '___FCC_MAIN__OFS_AMOUNTI___';
			if ('createEvent' in document) {
				var evt = document.createEvent('HTMLEvents');
				evt.initEvent('change', false, true);
				docIframe.getElementById('BLK_MAIN__TXN_ACC').dispatchEvent(evt);
				docIframe.getElementById('BLK_MAIN__OFS_ACC').dispatchEvent(evt);
				docIframe.getElementById('BLK_MAIN__OFS_CCY').dispatchEvent(evt);
				docIframe.getElementById('BLK_MAIN__OFS_AMOUNTI').dispatchEvent(evt);
			}
			else {
				docIframe.getElementById('BLK_MAIN__TXN_ACC').fireEvent('onchange');
				docIframe.getElementById('BLK_MAIN__OFS_ACC').fireEvent('onchange');
				docIframe.getElementById('BLK_MAIN__OFS_CCY').fireEvent('onchange');
				docIframe.getElementById('BLK_MAIN__OFS_AMOUNTI').fireEvent('onchange');
			}
		}, 500);
	}, 500);
}