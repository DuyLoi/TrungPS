document.getElementById('fastpath').value = 'DEDRTTLR';
document.getElementById('btnGo').click();