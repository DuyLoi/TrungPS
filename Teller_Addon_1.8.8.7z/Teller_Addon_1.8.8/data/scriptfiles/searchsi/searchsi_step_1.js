/**
 * Created by HuyNT2.
 * User:
 * Date: 21/04/2015
 * Time: 5:35 PM
 * Description: Nhập thông tin tìm kiếm lệnh SI
 */

var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (let tmpDivIframe of arrDivIframes) {
	//console.log("GOT DIV IFrame src: " + tmpDivIframe.getAttribute('id'));
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	//var arrIframes = tmpDivIframe.querySelector('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=SISTRONL') != -1)) {
		/*if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=ICSRATMA') != -1)) {*/
			console.log("GOT IFrame src: " + tmpIframeScr);
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_SIVWS_SISCONON__COUNTERPARTY').value = '00000175';
	/*docIframe.getElementById('BLK_ICTMSRATEDEF__CCYCODE').value = 'USD';*/
	docIframe.getElementById('Search').getElementsByTagName('a')[0].click();
}



