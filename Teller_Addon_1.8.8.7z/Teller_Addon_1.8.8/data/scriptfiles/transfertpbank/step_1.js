var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (var tmpDivIframe in arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=1006') != -1)) {
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value = '___FCC_TRANS_TPB_FROM_ACCNO___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNAMTI').value = '___FCC_TRANS_TPB_FROM_AMT___';
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__VIRACCNO').value = '___FCC_TRANS_TPB_TO_ACCNO___';
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("change", false, true);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNAMTI').dispatchEvent(evt);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__VIRACCNO').dispatchEvent(evt);
		var evt1 = document.createEvent("HTMLEvents");
		evt1.initEvent("blur", false, true);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt1);
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__VIRACCNO').dispatchEvent(evt1);
	}
	else {
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent("onchange");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNAMTI').fireEvent("onchange");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__VIRACCNO').fireEvent("onchange");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent("onblur");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__VIRACCNO').fireEvent("onblur");
	}
	setTimeout(function(){
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').value = '___FCC_TRANS_TPB_CONTENT___';
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').innerHTML = '___FCC_TRANS_TPB_CONTENT___';
		if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("change", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').dispatchEvent(evt);
			var evt1 = document.createEvent("HTMLEvents");
			evt1.initEvent("blur", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').dispatchEvent(evt1);
		}
		else {
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').fireEvent("onchange");
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').fireEvent("onblur");
		}
	}, 700);
	/*docIframe.getElementById('BTN_OK').click();*/
}