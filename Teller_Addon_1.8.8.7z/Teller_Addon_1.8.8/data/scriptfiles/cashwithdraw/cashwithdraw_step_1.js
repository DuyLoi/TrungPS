/**
 * Created by HuyNT2.
 * User:
 * Date: 21/04/2015
 * Time: 5:35 PM
 * Description: Nhập thông tin Rút tiền từ tài khoản
 */

var divTarget;
var iframeTarget;
var searchStatus = false;

var divLauncher = document.getElementById('IFlauncher');
var arrDivIframes = divLauncher.getElementsByTagName('div');
/*
	HuyNT2 note: không dùng {for .. var .. in ..} được mà phải dùng {for .. let .. of ..}
*/
for (let tmpDivIframe of arrDivIframes) {
	var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
	if (arrIframes && arrIframes.length > 0) {
		console.log('GET ELEMENT: IFRAME');
		var tmpIframe = arrIframes[0];
		var tmpIframeScr = tmpIframe.getAttribute('src');
		if((tmpIframeScr.indexOf('action=SMSStartLogServlet') != -1) && (tmpIframeScr.indexOf('funcid=1001') != -1)) {
			console.log("GOT IFrame src: " + tmpIframeScr);
			divTarget = tmpDivIframe;
			iframeTarget = tmpIframe;
			searchStatus = true;
			break;
		}	
	}	
}
if (searchStatus) {
	divTarget.style.zIndex = 10;
	var docIframe = iframeTarget.contentDocument;
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value = '00000182002';
	if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("change", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt);
			console.log("HuyNT2: fire event onchange");
		}
		else
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent("onchange");
	
	docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value = '1000000';
	setTimeout(function(){
		console.log("HuyNT2: fire event blur");
		if ("createEvent" in document) {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("blur", false, true);
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').dispatchEvent(evt);
			console.log("HuyNT2: fire event blur");
		}
		else
			docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').fireEvent("onblur");
		console.log("HuyNT2: fire event blur END");
		docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').value = 'RUT TIEN VOI ECOUNTER';
	}, 200);
	
	/*docIframe.getElementById('BTN_OK').click();*/
}



