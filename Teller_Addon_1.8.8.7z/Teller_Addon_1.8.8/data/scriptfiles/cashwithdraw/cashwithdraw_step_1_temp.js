var divTarget;var iframeTarget;var searchStatus=false;var divLauncher=document.getElementById('IFlauncher');var arrDivIframes=divLauncher.getElementsByTagName('div');for(let tmpDivIframe of arrDivIframes){var arrIframes=tmpDivIframe.getElementsByTagName('iframe');if(arrIframes&&arrIframes.length>0){var tmpIframe=arrIframes[0];var tmpIframeScr=tmpIframe.getAttribute('src');if(-1!=tmpIframeScr.indexOf('action=SMSStartLogServlet')&&-1!=tmpIframeScr.indexOf('funcid=1001')){console.log('GOT IFrame src: '+tmpIframeScr),divTarget=tmpDivIframe,iframeTarget=tmpIframe,searchStatus=true;break}}}if(searchStatus){divTarget.style.zIndex=10;var docIframe=iframeTarget.contentDocument;if(docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value='___FCC_CASH_WITHDRAW_ACCOUNT___','createEvent'in document){var evt=document.createEvent('HTMLEvents');evt.initEvent('change',false,true),docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt)}else docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent('onchange');docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value='___FCC_CASH_WITHDRAW_AMOUNT___',setTimeout(function(){if('createEvent'in document){var e=document.createEvent('HTMLEvents');e.initEvent('blur',false,true),docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').dispatchEvent(e)}else docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').fireEvent('onblur');docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').value='___FCC_CASH_WITHDRAW_CONTENT___'},200)}







