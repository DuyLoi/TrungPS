/**
 * Created by HuyNT2.
 * User:
 * Date: 21/04/2015
 * Time: 5:35 PM
 * Description: 
 */

var tbCustSignature = document.getElementById('TBL_QryRslts');
if (tbCustSignature.rows[0]) {
	if ("createEvent" in document) {
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent("dblclick", false, true);
		tbCustSignature.rows[0].dispatchEvent(evt);
		console.log("HuyNT2: fire event ondblclick");
	}
	else
		tbCustSignature.rows[0].fireEvent("ondblclick");
}



