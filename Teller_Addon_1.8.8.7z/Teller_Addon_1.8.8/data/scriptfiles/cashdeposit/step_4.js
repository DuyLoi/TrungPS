var divTarget, iframeTarget, searchStatus = !1,
    divLauncher = document.getElementById('IFlauncher'),
    arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
    var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
    if (arrIframes && arrIframes.length > 0) {
        console.log('GET ELEMENT: IFRAME');
        var tmpIframe = arrIframes[0],
            tmpIframeScr = tmpIframe.getAttribute('src');
        if (-1 != tmpIframeScr.indexOf('action=SMSStartLogServlet') && -1 != tmpIframeScr.indexOf('funcid=1401')) {
            divTarget = tmpDivIframe, iframeTarget = tmpIframe, searchStatus = !0;
            break
        }
    }
}
if (searchStatus) {
    divTarget.style.zIndex = 10;
    var docIframe = iframeTarget.contentDocument;
    docIframe.getElementById('TAB_UDF').click();
    setTimeout(function () {
        docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL0').value = '___FCC_CASH_DEPOSIT_NAME___';
        docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL1I').value = '___FCC_CASH_DEPOSIT_INDENTIFY___';
        docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL2I').value = '___FCC_CASH_DEPOSIT_DATE_ISSUE___';
        docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL3').value = '___FCC_CASH_DEPOSIT_PLACE_ISSUE___';
        docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL4').value = '___FCC_CASH_DEPOSIT_ADDRESS___';
        docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL5').value = '___FCC_CASH_DEPOSIT_PHONE___';
        if ('createEvent' in document) {
            var evt = document.createEvent('HTMLEvents');
            evt.initEvent('change', false, true);
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL0').dispatchEvent(evt);
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL1I').dispatchEvent(evt);
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL2I').dispatchEvent(evt);
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL3').dispatchEvent(evt);
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL4').dispatchEvent(evt);
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL5').dispatchEvent(evt);
        }
        else {
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL0').fireEvent('onchange');
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL1I').fireEvent('onchange');
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL2I').fireEvent('onchange');
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL3').fireEvent('onchange');
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL4').fireEvent('onchange');
            docIframe.getElementById('BLK_UDF_DETAILS_VIEW__FLDVAL5').fireEvent('onchange');
        }
    }, 200);
}