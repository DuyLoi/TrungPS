var divTarget, iframeTarget, iframeTarget2, iframeTarget3, searchStatus = !1,
    divLauncher = document.getElementById('IFlauncher'),
    arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
    var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
    if (arrIframes && arrIframes.length > 0) {
        console.log('GET ELEMENT: IFRAME');
        var tmpIframe = arrIframes[0],
            tmpIframeScr = tmpIframe.getAttribute('src');
        if (-1 != tmpIframeScr.indexOf('action=SMSStartLogServlet') && -1 != tmpIframeScr.indexOf('funcid=1401')) {
            divTarget = tmpDivIframe, iframeTarget = tmpIframe, searchStatus = !0;
            iframeTarget2 = tmpIframe.contentDocument.getElementById('ifrSubScreen');
            break
        }
    }
}
if (searchStatus) {
    divTarget.style.zIndex = 10;
    var docIframe = iframeTarget2.contentDocument;
    docIframe.getElementById('close').click();
    setTimeout(function () {
        docIframe.getElementById('close').click();
        setTimeout(function () {
            iframeTarget3 = iframeTarget.contentDocument.getElementById('ifr_AlertWin');
            var docIframe2 = iframeTarget3.contentDocument;
            docIframe2.getElementById('BTN_OK').click();
        }, 500)
    }, 500);
}