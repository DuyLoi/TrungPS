var divTarget, iframeTarget, searchStatus = !1,
    divLauncher = document.getElementById('IFlauncher'),
    arrDivIframes = divLauncher.getElementsByTagName('div');
for (let tmpDivIframe of arrDivIframes) {
    var arrIframes = tmpDivIframe.getElementsByTagName('iframe');
    if (arrIframes && arrIframes.length > 0) {
        console.log('GET ELEMENT: IFRAME');
        var tmpIframe = arrIframes[0],
            tmpIframeScr = tmpIframe.getAttribute('src');
        if (-1 != tmpIframeScr.indexOf('action=SMSStartLogServlet') && -1 != tmpIframeScr.indexOf('funcid=1401')) {
            divTarget = tmpDivIframe, iframeTarget = tmpIframe, searchStatus = !0;
            break
        }
    }
}
if (searchStatus) {
    divTarget.style.zIndex = 10;
    var docIframe = iframeTarget.contentDocument;
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').value = '___FCC_CASH_DEPOSIT_ACCOUNT___';
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value = '___FCC_CASH_DEPOSIT_AMOUNT___';
    docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').value = '___FCC_CASH_DEPOSIT_NARRATIVE___';
    if ('createEvent' in document) {
        var evt = document.createEvent('HTMLEvents');
        evt.initEvent('change', false, true);
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').dispatchEvent(evt);
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').dispatchEvent(evt);
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').dispatchEvent(evt);
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').dispatchEvent(evt);
    }
    else {
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__TXNACC').fireEvent('onchange');
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').fireEvent('onchange');
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__NARRATIVE').fireEvent('onchange');
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').fireEvent('onchange');
    }
    setTimeout(function () {
        docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = '___FCC_CASH_DEPOSIT_CURRENCY___';
        if ('createEvent' in document) {
            var evt = document.createEvent('HTMLEvents');
            evt.initEvent('change', false, true);
            docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').dispatchEvent(evt);
        }
        else {
            docIframe.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').fireEvent('onchange');
        }
    }, 200);
}