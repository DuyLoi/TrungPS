/**
 * Created by HuyNT2.
 * User:
 * Date: 21/04/2015
 * Time: 5:35 PM
 */

var CONST_DEBUG_MODE = true;

